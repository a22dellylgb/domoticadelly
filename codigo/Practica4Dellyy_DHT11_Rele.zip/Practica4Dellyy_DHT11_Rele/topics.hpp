
const char* temperatura_topic = "casa/sensores/temperatura1";
const char* humidade_topic = "casa/sensores/humidade1";
const char* depuracion_topic = "depuracion1";  
const char* rele_topic = "casa/actuadores/rele1";  
